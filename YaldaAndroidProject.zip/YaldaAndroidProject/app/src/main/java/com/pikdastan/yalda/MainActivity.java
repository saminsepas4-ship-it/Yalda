package com.pikdastan.yalda;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private final int purple = Color.rgb(40,18,63);
    private final int panel = Color.rgb(64,38,93);
    private final int lavender = Color.rgb(229,212,255);
    private LinearLayout root;
    private PdfRenderer renderer;
    private PdfRenderer.Page currentPage;
    private int currentPageIndex = 0;
    private int currentSection = 1;
    private ImageView pageImage;
    private TextView pageCounter;
    private File pdfFile;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(purple);
        getWindow().setNavigationBarColor(purple);
        showSplash();
        new Handler(Looper.getMainLooper()).postDelayed(this::showMenu, 2200);
    }

    private void setupRoot(int background) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL); root.setPadding(dp(20),dp(20),dp(20),dp(20));
        root.setBackgroundColor(background); setContentView(root);
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setTextDirection(View.TEXT_DIRECTION_RTL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setPadding(dp(8),dp(8),dp(8),dp(8)); return t;
    }
    private GradientDrawable shape(int color) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(16)); return d;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextSize(17); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setBackground(shape(panel)); b.setPadding(dp(10),dp(8),dp(10),dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)); lp.setMargins(0,dp(6),0,dp(6));
        root.addView(b,lp); b.setOnClickListener(v -> action.run()); return b;
    }
    private void showSplash() {
        setupRoot(Color.WHITE);
        try (InputStream in = getAssets().open("cover.png")) {
            android.graphics.Bitmap bmp = android.graphics.BitmapFactory.decodeStream(in);
            ImageView img = new ImageView(this); img.setImageBitmap(bmp); img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            root.addView(img,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f));
        } catch (Exception e) { root.addView(text("دختری به نام یلدا",24,purple,true)); }
    }
    private void showMenu() {
        closeReader(); setupRoot(purple);
        TextView logo = text("◉",54,lavender,true); root.addView(logo);
        root.addView(text("Yalda",30,Color.WHITE,true));
        root.addView(text("دختری به نام یلدا",18,lavender,false));
        View spacer = new View(this); root.addView(spacer,new LinearLayout.LayoutParams(1,dp(20)));
        button("فهرست", this::showContents);
        button("درباره ما", () -> new AlertDialog.Builder(this).setTitle("درباره ما")
                .setMessage("تهیه شده در مجموعه پیک داستان").setPositiveButton("باشه",(d,w)->{}).show());
        button("سخن نویسنده", () -> new AlertDialog.Builder(this).setTitle("سخن نویسنده")
                .setMessage("مجموعه دختری به نام یلدا رمانی است در سه فصل که این کتابچه فصل اول آن می‌باشد.\n\nبرای حمایت از بنده داستان را از طریق کانال پیک داستان پیگیری کنید\n\nبا تشکر")
                .setPositiveButton("باشه",(d,w)->{}).show());
        button("خروج", () -> new AlertDialog.Builder(this).setTitle("خروج از برنامه؟")
                .setMessage("می‌خواهید از Yalda خارج شوید؟").setNegativeButton("لغو",(d,w)->{})
                .setPositiveButton("خروج",(d,w)->finish()).show());
    }
    private void showContents() {
        closeReader(); setupRoot(purple);
        root.addView(text("فهرست کتاب",26,Color.WHITE,true));
        root.addView(text("دختری به نام یلدا",16,lavender,false));
        ScrollView scroll = new ScrollView(this); LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list); root.addView(scroll,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f));
        int[] starts={1,31,61,91,121}; int[] ends={30,60,90,120,141};
        for(int i=0;i<5;i++) {
            final int section=i+1;
            Button b=new Button(this); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setTextSize(17);
            b.setText("بخش "+fa(section)+"     (صفحه "+fa(starts[i])+" تا "+fa(ends[i])+")"); b.setBackground(shape(panel));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(58)); lp.setMargins(0,dp(6),0,dp(6)); list.addView(b,lp);
            b.setOnClickListener(v->openSection(section));
        }
        button("بازگشت به منو",this::showMenu);
    }
    private String fa(int n) { return String.valueOf(n).replace('0','۰').replace('1','۱').replace('2','۲').replace('3','۳').replace('4','۴').replace('5','۵').replace('6','۶').replace('7','۷').replace('8','۸').replace('9','۹'); }
    private void openSection(int section) {
        closeReader(); currentSection=section; currentPageIndex=0;
        try {
            pdfFile=new File(getCacheDir(),"section_"+section+".pdf");
            try(InputStream in=getAssets().open("section_"+section+".pdf"); FileOutputStream out=new FileOutputStream(pdfFile)) {
                byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0) out.write(buf,0,n);
            }
            renderer=new PdfRenderer(android.os.ParcelFileDescriptor.open(pdfFile,android.os.ParcelFileDescriptor.MODE_READ_ONLY));
            showReader(); renderPage();
        } catch(Exception e) { new AlertDialog.Builder(this).setMessage("باز کردن این بخش ممکن نشد.").setPositiveButton("باشه",null).show(); }
    }
    private void showReader() {
        setupRoot(Color.rgb(248,245,252));
        TextView title=text("دختری به نام یلدا — بخش "+fa(currentSection),18,purple,true); root.addView(title);
        ScrollView sc=new ScrollView(this); pageImage=new ImageView(this); pageImage.setAdjustViewBounds(true); pageImage.setScaleType(ImageView.ScaleType.FIT_CENTER); sc.addView(pageImage);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1f));
        pageCounter=text("",14,purple,false); root.addView(pageCounter);
        LinearLayout controls=new LinearLayout(this); controls.setGravity(Gravity.CENTER); controls.setOrientation(LinearLayout.HORIZONTAL);
        Button prev=new Button(this); prev.setText("قبلی"); prev.setAllCaps(false); prev.setOnClickListener(v->{if(currentPageIndex>0){currentPageIndex--;renderPage();}});
        Button next=new Button(this); next.setText("بعدی"); next.setAllCaps(false); next.setOnClickListener(v->{if(renderer!=null&&currentPageIndex<renderer.getPageCount()-1){currentPageIndex++;renderPage();}});
        controls.addView(prev,new LinearLayout.LayoutParams(0,dp(48),1)); controls.addView(next,new LinearLayout.LayoutParams(0,dp(48),1)); root.addView(controls);
        Button back=new Button(this); back.setText("بازگشت به فهرست"); back.setAllCaps(false); back.setOnClickListener(v->showContents()); root.addView(back,new LinearLayout.LayoutParams(-1,dp(48)));
    }
    private void renderPage() {
        if(renderer==null||pageImage==null)return;
        if(currentPage!=null){currentPage.close();currentPage=null;}
        currentPage=renderer.openPage(currentPageIndex);
        int w=Math.max(500,getResources().getDisplayMetrics().widthPixels- dp(40));
        int h=(int)(w*(currentPage.getHeight()/(float)currentPage.getWidth()));
        Bitmap bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); bmp.eraseColor(Color.WHITE);
        currentPage.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); pageImage.setImageBitmap(bmp);
        pageCounter.setText("صفحه "+fa(currentPageIndex+1)+" از "+fa(renderer.getPageCount()));
    }
    private void closeReader() {
        try { if(currentPage!=null){currentPage.close();currentPage=null;} } catch(Exception ignored){}
        try { if(renderer!=null){renderer.close();renderer=null;} } catch(Exception ignored){}
        pageImage=null; pageCounter=null;
    }
    @Override protected void onDestroy(){closeReader();super.onDestroy();}
}
